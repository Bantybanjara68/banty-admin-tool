BANTY ADMIN PANEL V1
Open index.html in a browser.

This is a local demo/admin UI. It stores demo data in browser localStorage.
It does NOT implement real payment verification, server-side wallet balances,
secure license validation, or remote APK control yet. Those require a backend/API.
No Supabase connection is included.
